<?php

    // CST-126 Blog Project 1.0
    // Login Failed Response Module version 1.0
    // Jackie Adair
    // 30 June 19
    // Login Response Messages

?>
<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <h2><?php echo $message; ?></h2>
    </body>
</html>