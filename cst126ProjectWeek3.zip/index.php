<?php require_once('config.php') ?>
<?php require_once('functions.php') ?>
<?php require_once('registerLogin.php') ?>

<?php require_once('head_section.php') ?>
    <title>CST126</title>
</head>
<body>
    <div class="container">
        <!-- navbar -->
        <?php include('navbar.php') ?>

        <!-- page -->
        <div class="content">
            <h2 class="content-title">Latest</h2>
            <hr>
            <hr>
            
        </div>
<?php include('footer.php') ?>